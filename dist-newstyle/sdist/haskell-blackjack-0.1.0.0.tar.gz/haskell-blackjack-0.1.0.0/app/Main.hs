module Main where

import System.Random (newStdGen, randomRs)
import Data.List (intercalate)

data Suit = Clubs | Diamonds | Hearts | Spades deriving (Show, Enum, Bounded)
data Rank = Two | Three | Four | Five | Six | Seven | Eight | Nine | Ten | Jack | Queen | King | Ace deriving (Show, Enum, Bounded)
data Card = Card { rank :: Rank, suit :: Suit } deriving (Eq)

instance Show Card where
    show (Card rank suit) = show rank ++ " of " ++ show suit

type Deck = [Card]
type Hand = [Card]

allSuits :: [Suit]
allSuits = [minBound .. maxBound]

allRanks :: [Rank]
allRanks = [minBound .. maxBound]

fullDeck :: Deck
fullDeck = [Card rank suit | suit <- allSuits, rank <- allRanks]

-- Shuffling the deck
shuffleDeck :: Deck -> IO Deck
shuffleDeck deck = do
    gen <- newStdGen
    return $ map (deck !!) . take 52 $ nub $ randomRs (0, 51) gen

-- Deal a card, returning the card and the remaining deck
dealCard :: Deck -> (Card, Deck)
dealCard (x:xs) = (x, xs)

-- Calculate the score of a hand
calculateScore :: Hand -> Int
calculateScore hand = sum $ map cardValue hand
    where
        cardValue (Card rank _) = case rank of
            Ace -> 11
            King -> 10
            Queen -> 10
            Jack -> 10
            _ -> fromEnum rank + 2

-- Adjust for Aces
adjustForAces :: Hand -> Int
adjustForAces hand
    | score > 21 && numAces > 0 = adjustForAces (tail aceAdjustedHand) + 1
    | otherwise = score
    where
        score = calculateScore hand
        numAces = length $ filter ((== Ace) . rank) hand
        aceAdjustedHand = map adjustAce hand
        adjustAce (Card Ace suit) = Card Two suit -- Treat Ace as 1 instead of 11
        adjustAce card = card

-- Main game loop
main :: IO ()
main = do
    shuffledDeck <- shuffleDeck fullDeck
    let (playerCard1, deckAfterFirstDeal) = dealCard shuffledDeck
    let (playerCard2, deckAfterSecondDeal) = dealCard deckAfterFirstDeal
    let playerHand = [playerCard1, playerCard2]
    putStrLn "Your hand is:"
    printHand playerHand
    let playerScore = adjustForAces playerHand
    putStrLn $ "Your score: " ++ show playerScore
    -- Add dealer logic and comparison to determine winner

printHand :: Hand -> IO ()
printHand hand = putStrLn $ intercalate ", " (map show hand)
